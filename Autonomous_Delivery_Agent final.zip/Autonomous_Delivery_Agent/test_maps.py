#!/usr/bin/env python3
"""
Test script for map generation and loading
CSA2001 Project Map Testing
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from complete_delivery_agent import *
import json

def test_map_generation():
    """Test built-in map generators"""
    print("🗺️  Testing Map Generation")
    print("=" * 30)

    maps = [
        ('Small', MapGenerator.create_small_map),
        ('Medium', MapGenerator.create_medium_map), 
        ('Large', MapGenerator.create_large_map)
    ]

    for name, generator in maps:
        try:
            grid = generator()
            print(f"{name:8} | Size: {grid.width:2d}x{grid.height:2d} | ✅ Generated")

            # Test pathfinding on each map
            agent = AutonomousDeliveryAgent(grid)
            start = Position(0, 0)
            goal = Position(grid.width-1, grid.height-1)

            result = agent.execute_delivery(start, goal, 'astar')
            status = "✅ Navigable" if result['path_found'] else "❌ No path"
            print(f"         | Test: {status} | Cost: {result['total_cost']:6.1f}")

        except Exception as e:
            print(f"{name:8} | ❌ Error: {e}")

def test_dynamic_map():
    """Test dynamic obstacle map"""
    print("\n🚧 Testing Dynamic Map")
    print("=" * 25)

    try:
        grid, obstacles = MapGenerator.create_dynamic_obstacle_map()
        print(f"Grid Size: {grid.width}x{grid.height}")
        print(f"Dynamic Obstacles: {len(obstacles)}")

        # Test obstacle movement
        for i, obstacle in enumerate(obstacles):
            print(f"\nObstacle {i+1}:")
            print(f"  Initial: {obstacle.initial_position}")
            print(f"  Path: {[str(p) for p in obstacle.path[:3]]}...")

            # Show movement over time
            positions = [str(obstacle.get_position_at_time(t)) for t in range(4)]
            print(f"  Movement: {' -> '.join(positions)}")

    except Exception as e:
        print(f"❌ Dynamic map test failed: {e}")

def test_json_maps():
    """Test loading maps from JSON files"""
    print("\n📁 Testing JSON Map Loading")
    print("=" * 35)

    map_files = [
        'maps/small_map.json',
        'maps/medium_map.json', 
        'maps/large_map.json',
        'maps/dynamic_map.json'
    ]

    for map_file in map_files:
        try:
            if os.path.exists(map_file):
                with open(map_file, 'r') as f:
                    data = json.load(f)

                print(f"{os.path.basename(map_file):18} | Size: {data['width']:2d}x{data['height']:2d} | "
                      f"Cells: {len(data['cells']):3d} | ✅ Loaded")

                # Validate JSON structure
                required_keys = ['width', 'height', 'cells']
                missing = [key for key in required_keys if key not in data]
                if missing:
                    print(f"                     | ❌ Missing keys: {missing}")

            else:
                print(f"{os.path.basename(map_file):18} | ❌ File not found")

        except Exception as e:
            print(f"{os.path.basename(map_file):18} | ❌ Error: {e}")

def validate_map_connectivity():
    """Validate that maps have valid paths from start to goal"""
    print("\n🔍 Testing Map Connectivity")
    print("=" * 30)

    test_cases = [
        ('Small Map', MapGenerator.create_small_map(), Position(0,0), Position(9,9)),
        ('Medium Map', MapGenerator.create_medium_map(), Position(0,0), Position(19,19)),
    ]

    for name, grid, start, goal in test_cases:
        agent = AutonomousDeliveryAgent(grid)

        # Test with different algorithms
        connectivity_results = {}
        for algorithm in ['bfs', 'ucs', 'astar']:
            result = agent.execute_delivery(start, goal, algorithm)
            connectivity_results[algorithm] = result['path_found']

        all_connected = all(connectivity_results.values())
        status = "✅ Connected" if all_connected else "❌ Disconnected"

        print(f"{name:12} | {status} | BFS:{connectivity_results['bfs']} "
              f"UCS:{connectivity_results['ucs']} A*:{connectivity_results['astar']}")

def run_map_tests():
    """Run all map-related tests"""
    print("🗺️  CSA2001 Map Testing Suite")
    print("=" * 35)

    test_map_generation()
    test_dynamic_map() 
    test_json_maps()
    validate_map_connectivity()

    print("\n✅ Map testing completed!")

if __name__ == "__main__":
    run_map_tests()
