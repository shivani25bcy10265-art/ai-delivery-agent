# 3. Sample Map JSON files
import json
import os

# Create maps directory
os.makedirs('maps', exist_ok=True)

# Small Map JSON
small_map = {
    "name": "Small Test Map",
    "description": "10x10 grid with basic obstacles and varied terrain",
    "width": 10,
    "height": 10,
    "cells": [
        # Static obstacles
        {"x": 3, "y": 3, "type": 1, "terrain_cost": 1},
        {"x": 3, "y": 4, "type": 1, "terrain_cost": 1},
        {"x": 3, "y": 5, "type": 1, "terrain_cost": 1},
        {"x": 6, "y": 6, "type": 1, "terrain_cost": 1},
        {"x": 6, "y": 7, "type": 1, "terrain_cost": 1},
        {"x": 7, "y": 6, "type": 1, "terrain_cost": 1},
        {"x": 7, "y": 7, "type": 1, "terrain_cost": 1},
        
        # Difficult terrain (cost = 3)
        {"x": 2, "y": 7, "type": 0, "terrain_cost": 3},
        {"x": 2, "y": 8, "type": 0, "terrain_cost": 3},
        {"x": 2, "y": 9, "type": 0, "terrain_cost": 3},
        {"x": 3, "y": 7, "type": 0, "terrain_cost": 3},
        {"x": 3, "y": 8, "type": 0, "terrain_cost": 3},
        {"x": 3, "y": 9, "type": 0, "terrain_cost": 3},
        {"x": 4, "y": 7, "type": 0, "terrain_cost": 3},
        {"x": 4, "y": 8, "type": 0, "terrain_cost": 3},
        {"x": 4, "y": 9, "type": 0, "terrain_cost": 3},
        
        # Start and goal positions
        {"x": 0, "y": 0, "type": 2, "terrain_cost": 1},
        {"x": 9, "y": 9, "type": 3, "terrain_cost": 1}
    ]
}

with open('maps/small_map.json', 'w') as f:
    json.dump(small_map, f, indent=2)

# Medium Map JSON
medium_map = {
    "name": "Medium Maze Map",
    "description": "20x20 grid with maze-like structure",
    "width": 20,
    "height": 20,
    "cells": []
}

# Add maze walls
for x in range(5, 15):
    medium_map["cells"].extend([
        {"x": x, "y": 5, "type": 1, "terrain_cost": 1},
        {"x": x, "y": 15, "type": 1, "terrain_cost": 1}
    ])

for y in range(5, 16):
    medium_map["cells"].extend([
        {"x": 5, "y": y, "type": 1, "terrain_cost": 1},
        {"x": 15, "y": y, "type": 1, "terrain_cost": 1}
    ])

# Add gaps in walls
medium_map["cells"].extend([
    {"x": 10, "y": 5, "type": 0, "terrain_cost": 1},
    {"x": 5, "y": 10, "type": 0, "terrain_cost": 1},
    {"x": 15, "y": 10, "type": 0, "terrain_cost": 1}
])

# Add varied terrain in corner
for x in range(0, 5):
    for y in range(0, 5):
        medium_map["cells"].append({"x": x, "y": y, "type": 0, "terrain_cost": 2})

# Add start and goal
medium_map["cells"].extend([
    {"x": 0, "y": 0, "type": 2, "terrain_cost": 1},
    {"x": 19, "y": 19, "type": 3, "terrain_cost": 1}
])

with open('maps/medium_map.json', 'w') as f:
    json.dump(medium_map, f, indent=2)

# Large Map JSON (simplified version - full random would be too large)
large_map = {
    "name": "Large Complex Map",
    "description": "50x50 grid with random obstacles and varied terrain",
    "width": 50,
    "height": 50,
    "cells": []
}

# Add sample obstacles and terrain (representative subset)
import random
random.seed(42)

for x in range(0, 50, 5):  # Sample every 5th cell to keep JSON manageable
    for y in range(0, 50, 5):
        if random.random() < 0.2:
            large_map["cells"].append({"x": x, "y": y, "type": 1, "terrain_cost": 1})
        elif random.random() < 0.3:
            cost = random.randint(2, 5)
            large_map["cells"].append({"x": x, "y": y, "type": 0, "terrain_cost": cost})

# Ensure start and goal are clear
large_map["cells"].extend([
    {"x": 0, "y": 0, "type": 2, "terrain_cost": 1},
    {"x": 49, "y": 49, "type": 3, "terrain_cost": 1}
])

with open('maps/large_map.json', 'w') as f:
    json.dump(large_map, f, indent=2)

# Dynamic Map JSON
dynamic_map = {
    "name": "Dynamic Obstacles Map", 
    "description": "15x15 grid with moving obstacles",
    "width": 15,
    "height": 15,
    "cells": [
        # Static obstacle wall
        {"x": 5, "y": 7, "type": 1, "terrain_cost": 1},
        {"x": 6, "y": 7, "type": 1, "terrain_cost": 1},
        {"x": 7, "y": 7, "type": 1, "terrain_cost": 1},
        {"x": 8, "y": 7, "type": 1, "terrain_cost": 1},
        {"x": 9, "y": 7, "type": 1, "terrain_cost": 1},
        
        # Start and goal
        {"x": 0, "y": 0, "type": 2, "terrain_cost": 1},
        {"x": 14, "y": 14, "type": 3, "terrain_cost": 1}
    ],
    "dynamic_obstacles": [
        {
            "id": "moving_obstacle_1",
            "initial_position": {"x": 2, "y": 5},
            "path": [
                {"x": 2, "y": 5},
                {"x": 3, "y": 5}, 
                {"x": 4, "y": 5},
                {"x": 3, "y": 5}
            ],
            "speed": 1
        },
        {
            "id": "moving_obstacle_2", 
            "initial_position": {"x": 10, "y": 10},
            "path": [
                {"x": 10, "y": 10},
                {"x": 11, "y": 10},
                {"x": 11, "y": 11},
                {"x": 10, "y": 11}
            ],
            "speed": 1
        }
    ]
}

with open('maps/dynamic_map.json', 'w') as f:
    json.dump(dynamic_map, f, indent=2)

print("✅ Map JSON files created:")
print("  - maps/small_map.json")
print("  - maps/medium_map.json") 
print("  - maps/large_map.json")
print("  - maps/dynamic_map.json")