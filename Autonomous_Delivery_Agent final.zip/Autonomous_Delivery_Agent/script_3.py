# 4. .gitignore file
gitignore_content = '''# CSA2001 Autonomous Delivery Agent - Git Ignore File

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Virtual Environment
venv/
env/
ENV/
.venv/
.env

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# OS
.DS_Store
.DS_Store?
._*
.Spotlight-V100
.Trashes
ehthumbs.db
Thumbs.db

# Project specific
results/*.json
results/*.txt
*.log
temp/
output/

# Academic
*.pdf
*.docx
report_draft*
presentation*

# Backup files
*.bak
*.backup
*.old
'''

with open('.gitignore', 'w') as f:
    f.write(gitignore_content)

print("✅ .gitignore created")