# 2. requirements.txt - Dependencies file
requirements_content = '''# CSA2001 Autonomous Delivery Agent
# No external dependencies required - uses Python standard library only

# Python version requirement
python>=3.7

# Standard library modules used:
# - heapq (priority queue for search algorithms)
# - random (for simulated annealing and map generation)  
# - math (for heuristic calculations)
# - time (for performance timing)
# - json (for map file I/O)
# - argparse (for command-line interface)
# - typing (for type hints)
# - dataclasses (for data structures)
# - enum (for cell types)
# - collections (for deque in BFS)

# Optional development dependencies (not required for core functionality):
# pytest>=6.0.0  # For unit testing
# black>=21.0.0  # For code formatting  
# mypy>=0.900   # For type checking
'''

with open('requirements.txt', 'w') as f:
    f.write(requirements_content)

print("✅ requirements.txt created")