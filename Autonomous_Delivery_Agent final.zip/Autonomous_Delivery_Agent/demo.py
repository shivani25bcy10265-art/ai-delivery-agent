#!/usr/bin/env python3
"""
Demo Script - CSA2001 Autonomous Delivery Agent
Quick demonstration of key features and capabilities
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from complete_delivery_agent import *
import json

def print_header(title):
    """Print a formatted header"""
    print(f"\n{'='*50}")
    print(f"🤖 {title}")
    print(f"{'='*50}")

def print_section(title):
    """Print a formatted section header"""  
    print(f"\n📋 {title}")
    print("-" * 30)

def demo_basic_algorithms():
    """Demonstrate basic pathfinding algorithms"""
    print_section("Basic Algorithm Comparison")

    grid = MapGenerator.create_small_map()
    agent = AutonomousDeliveryAgent(grid)
    start = Position(0, 0)
    goal = Position(9, 9)

    print(f"Map: 10x10 grid | Route: {start} → {goal}")
    print()

    algorithms = ['bfs', 'ucs', 'astar']
    results = []

    for algorithm in algorithms:
        result = agent.execute_delivery(start, goal, algorithm)
        results.append(result)

        print(f"{algorithm.upper():5} | "
              f"Cost: {result['total_cost']:6.1f} | "
              f"Nodes: {result['total_nodes_expanded']:4d} | "
              f"Time: {result['total_time']:7.4f}s | "
              f"Success: {'✅' if result['path_found'] else '❌'}")

    # Find best performer
    if results:
        best_time = min(r for r in results if r['path_found'], key=lambda x: x['total_time'])
        best_nodes = min(r for r in results if r['path_found'], key=lambda x: x['total_nodes_expanded'])

        print(f"\n🏆 Fastest: {best_time['algorithm'].upper()}")
        print(f"🏆 Most Efficient: {best_nodes['algorithm'].upper()}")

def demo_dynamic_replanning():
    """Demonstrate dynamic obstacle handling"""
    print_section("Dynamic Replanning Demo")

    grid, obstacles = MapGenerator.create_dynamic_obstacle_map()
    agent = AutonomousDeliveryAgent(grid)

    for obstacle in obstacles:
        agent.add_dynamic_obstacle(obstacle)

    start = Position(0, 0)
    goal = Position(14, 14)

    print(f"Map: 15x15 with {len(obstacles)} moving obstacles")
    print(f"Route: {start} → {goal}")

    result = agent.execute_delivery(start, goal, 'astar')

    print(f"\nResults:")
    print(f"  Success: {'✅' if result['path_found'] else '❌'}")
    print(f"  Total Cost: {result['total_cost']}")
    print(f"  Replanning Events: {len(result['replanning_events'])}")

    if result['replanning_events']:
        print(f"\n🚧 Replanning Details:")
        for i, event in enumerate(result['replanning_events'], 1):
            print(f"    {i}. Time Step {event['time_step']}: {event['trigger']}")
            print(f"       New Path Cost: {event['new_path_cost']:.1f}")

def demo_heuristic_comparison():
    """Compare different heuristic functions"""
    print_section("Heuristic Function Comparison")

    grid = MapGenerator.create_medium_map()
    agent = AutonomousDeliveryAgent(grid)
    start = Position(0, 0)
    goal = Position(19, 19)

    heuristics = ['manhattan', 'euclidean']

    print(f"Map: 20x20 maze | Route: {start} → {goal}")
    print()

    for heuristic in heuristics:
        result = agent.plan_path('astar', heuristic)
        print(f"{heuristic.capitalize():10} | "
              f"Nodes: {result.nodes_expanded:4d} | "
              f"Cost: {result.cost:6.1f} | "
              f"Time: {result.time_taken:.4f}s")

def demo_scalability():
    """Test performance on different map sizes"""
    print_section("Scalability Analysis")

    test_maps = [
        ("Small",  MapGenerator.create_small_map,  Position(0,0), Position(9,9)),
        ("Medium", MapGenerator.create_medium_map, Position(0,0), Position(19,19)),
        ("Large",  MapGenerator.create_large_map,  Position(0,0), Position(49,49))
    ]

    print(f"{'Map':8} | {'Size':8} | {'Nodes':8} | {'Time':10} | {'Status':8}")
    print("-" * 50)

    for name, generator, start, goal in test_maps:
        grid = generator()
        agent = AutonomousDeliveryAgent(grid)

        result = agent.execute_delivery(start, goal, 'astar')
        status = "✅ Success" if result['path_found'] else "❌ Failed"

        print(f"{name:8} | {grid.width:2d}x{grid.height:2d}    | "
              f"{result['total_nodes_expanded']:8d} | "
              f"{result['total_time']:8.4f}s | {status}")

def demo_export_results():
    """Demonstrate result export functionality"""
    print_section("Results Export Demo")

    grid = MapGenerator.create_small_map()
    evaluator = PerformanceEvaluator()

    results = evaluator.compare_algorithms(
        grid, Position(0,0), Position(9,9)
    )

    # Save to JSON
    output_file = 'results/demo_results.json'
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2, default=str)

    print(f"✅ Results exported to: {output_file}")
    print(f"📊 Comparison includes: {', '.join(results.keys())}")

def main():
    """Run complete demonstration"""
    print_header("Autonomous Delivery Agent Demo")

    print("This demo showcases the key capabilities of the autonomous delivery agent:")
    print("• Multiple pathfinding algorithms (BFS, UCS, A*)")  
    print("• Dynamic obstacle detection and replanning")
    print("• Heuristic function comparison")
    print("• Performance analysis across map sizes")
    print("• Results export for academic analysis")

    try:
        demo_basic_algorithms()
        demo_heuristic_comparison() 
        demo_dynamic_replanning()
        demo_scalability()
        demo_export_results()

        print_section("Demo Completed Successfully!")
        print("For more detailed testing, run:")
        print("  python tests/test_algorithms.py")
        print("  python tests/test_maps.py")
        print()
        print("For custom experiments, use the CLI:")
        print("  python complete_delivery_agent.py --help")

        return 0

    except Exception as e:
        print(f"\n❌ Demo failed with error: {e}")
        return 1

if __name__ == "__main__":
    exit(main())
