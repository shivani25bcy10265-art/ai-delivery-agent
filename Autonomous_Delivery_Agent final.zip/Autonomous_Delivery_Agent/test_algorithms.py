#!/usr/bin/env python3
"""
Test script for autonomous delivery agent algorithms
CSA2001 Project Testing Suite
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from complete_delivery_agent import *
import time

def test_algorithms():
    """Test all pathfinding algorithms on different maps"""
    print("🧪 Testing Pathfinding Algorithms")
    print("=" * 40)

    # Test configurations
    test_cases = [
        {
            'name': 'Small Map Test',
            'grid': MapGenerator.create_small_map(),
            'start': Position(0, 0),
            'goal': Position(9, 9)
        },
        {
            'name': 'Medium Map Test', 
            'grid': MapGenerator.create_medium_map(),
            'start': Position(0, 0),
            'goal': Position(19, 19)
        }
    ]

    algorithms = ['bfs', 'ucs', 'astar']

    for test_case in test_cases:
        print(f"\n📋 {test_case['name']}")
        print("-" * 25)

        agent = AutonomousDeliveryAgent(test_case['grid'])

        for algorithm in algorithms:
            try:
                result = agent.execute_delivery(
                    test_case['start'], 
                    test_case['goal'], 
                    algorithm
                )

                status = "✅ PASS" if result['path_found'] else "❌ FAIL"
                print(f"{algorithm.upper():5} | {status} | Cost: {result['total_cost']:6.1f} | "
                      f"Nodes: {result['total_nodes_expanded']:4d} | "
                      f"Time: {result['total_time']:7.4f}s")

            except Exception as e:
                print(f"{algorithm.upper():5} | ❌ ERROR: {e}")

def test_dynamic_replanning():
    """Test dynamic obstacle handling"""
    print("\n🚧 Testing Dynamic Replanning")
    print("=" * 35)

    grid, obstacles = MapGenerator.create_dynamic_obstacle_map()
    agent = AutonomousDeliveryAgent(grid)

    for obstacle in obstacles:
        agent.add_dynamic_obstacle(obstacle)

    result = agent.execute_delivery(Position(0, 0), Position(14, 14), 'astar')

    print(f"Success: {result['path_found']}")
    print(f"Total Cost: {result['total_cost']}")
    print(f"Replanning Events: {len(result['replanning_events'])}")

    if result['replanning_events']:
        print("\nReplanning Details:")
        for i, event in enumerate(result['replanning_events']):
            print(f"  Event {i+1}: Step {event['time_step']}, Trigger: {event['trigger']}")

    return result['path_found']

def test_heuristics():
    """Test different heuristic functions"""
    print("\n🎯 Testing Heuristics")
    print("=" * 25)

    grid = MapGenerator.create_small_map()
    agent = AutonomousDeliveryAgent(grid)

    heuristics = ['manhattan', 'euclidean']

    for heuristic in heuristics:
        result = agent.plan_path('astar', heuristic)
        print(f"{heuristic.capitalize():10} | Nodes: {result.nodes_expanded:3d} | "
              f"Cost: {result.cost:6.1f} | Time: {result.time_taken:.4f}s")

def run_all_tests():
    """Run complete test suite"""
    print("🤖 CSA2001 Autonomous Delivery Agent - Test Suite")
    print("=" * 55)

    tests_passed = 0
    total_tests = 3

    try:
        test_algorithms()
        tests_passed += 1
    except Exception as e:
        print(f"❌ Algorithm tests failed: {e}")

    try:
        if test_dynamic_replanning():
            tests_passed += 1
        else:
            print("❌ Dynamic replanning test failed")
    except Exception as e:
        print(f"❌ Dynamic replanning test error: {e}")

    try:
        test_heuristics()
        tests_passed += 1
    except Exception as e:
        print(f"❌ Heuristics test failed: {e}")

    print(f"\n📊 Test Results: {tests_passed}/{total_tests} tests passed")

    if tests_passed == total_tests:
        print("✅ All tests passed! System is working correctly.")
        return 0
    else:
        print("❌ Some tests failed. Please check the implementation.")
        return 1

if __name__ == "__main__":
    exit(run_all_tests())
