#!/usr/bin/env python3
"""
Autonomous Delivery Agent - CSA2001 AI/ML Project

Implements:
- 2D grid environment (static obstacles, varying terrain costs, dynamic obstacles)
- Rational agent (time, fuel efficiency)
- BFS, UCS, A*, hill climbing, simulated annealing
- Test maps, performance evaluation, dynamic replanning log

Author: [Your Name]
Date: September 2025
"""

import heapq
import random
import math
import time
import json
import argparse
from typing import List, Tuple, Set, Dict
from dataclasses import dataclass
from enum import Enum
from collections import deque

###########################
# Basic Grid Definitions  #
###########################

class CellType(Enum):
    FREE = 0
    OBSTACLE = 1
    START = 2
    GOAL = 3
    DYNAMIC_OBSTACLE = 4

@dataclass
class Position:
    x: int
    y: int
    def __eq__(self, other):
        return isinstance(other, Position) and self.x == other.x and self.y == other.y
    def __hash__(self):
        return hash((self.x, self.y))
    def __add__(self, other):
        return Position(self.x + other.x, self.y + other.y)
    def __repr__(self):
        return f"({self.x},{self.y})"

@dataclass
class GridCell:
    position: Position
    cell_type: CellType
    terrain_cost: int = 1

class Grid:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.cells = [[GridCell(Position(x, y), CellType.FREE) for y in range(height)] for x in range(width)]

    def is_valid(self, pos: Position) -> bool:
        return 0 <= pos.x < self.width and 0 <= pos.y < self.height

    def is_passable(self, pos: Position) -> bool:
        if not self.is_valid(pos): return False
        cell_type = self.cells[pos.x][pos.y].cell_type
        return cell_type not in [CellType.OBSTACLE, CellType.DYNAMIC_OBSTACLE]

    def get_terrain_cost(self, pos: Position) -> int:
        if not self.is_valid(pos): return float('inf')
        return self.cells[pos.x][pos.y].terrain_cost

    def set_cell_type(self, pos: Position, cell_type: CellType):
        if self.is_valid(pos): self.cells[pos.x][pos.y].cell_type = cell_type

    def set_terrain_cost(self, pos: Position, cost: int):
        if self.is_valid(pos): self.cells[pos.x][pos.y].terrain_cost = cost

    def get_neighbors(self, pos: Position) -> List[Position]:
        directions = [Position(0,1), Position(0,-1), Position(1,0), Position(-1,0)] # 4-connected
        result = []
        for d in directions:
            n = pos + d
            if self.is_valid(n) and self.is_passable(n):
                result.append(n)
        return result

    def display(self):
        print("Grid Layout:")
        for y in range(self.height):
            row = ""
            for x in range(self.width):
                cell = self.cells[x][y]
                if cell.cell_type == CellType.START: row += "S "
                elif cell.cell_type == CellType.GOAL: row += "G "
                elif cell.cell_type == CellType.OBSTACLE: row += "# "
                elif cell.cell_type == CellType.DYNAMIC_OBSTACLE: row += "D "
                else: row += str(cell.terrain_cost) + " "
            print(row)
        print()

####################
# Search Algorithms#
####################

class SearchResult:
    def __init__(self, path=None, cost=float('inf'), nodes_expanded=0, time_taken=0.0):
        self.path = path or []
        self.cost = cost
        self.nodes_expanded = nodes_expanded
        self.time_taken = time_taken
        self.found_solution = bool(self.path)

class BreadthFirstSearch:
    def search(self, grid: Grid, start: Position, goal: Position) -> SearchResult:
        start_time = time.time()
        nodes_expanded = 0
        if start == goal:
            return SearchResult([start], 0, 0, 0)
        queue = deque([(start, [start])])
        visited = {start}
        while queue:
            current, path = queue.popleft()
            nodes_expanded += 1
            for neighbor in grid.get_neighbors(current):
                if neighbor not in visited:
                    visited.add(neighbor)
                    new_path = path + [neighbor]
                    if neighbor == goal:
                        return SearchResult(new_path, len(new_path)-1, nodes_expanded, time.time()-start_time)
                    queue.append((neighbor, new_path))
        return SearchResult([], float('inf'), nodes_expanded, time.time()-start_time)

class UniformCostSearch:
    def search(self, grid: Grid, start: Position, goal: Position) -> SearchResult:
        start_time = time.time()
        nodes_expanded = 0
        if start == goal: return SearchResult([start], 0, 0, 0)
        queue = [(0, start, [start])]
        visited = set()
        while queue:
            current_cost, current, path = heapq.heappop(queue)
            if current in visited: continue
            visited.add(current); nodes_expanded += 1
            if current == goal:
                return SearchResult(path, current_cost, nodes_expanded, time.time() - start_time)
            for neighbor in grid.get_neighbors(current):
                if neighbor not in visited:
                    new_cost = current_cost + grid.get_terrain_cost(neighbor)
                    heapq.heappush(queue, (new_cost, neighbor, path + [neighbor]))
        return SearchResult([], float('inf'), nodes_expanded, time.time()-start_time)

class AStarSearch:
    def manhattan_distance(self, a: Position, b: Position):
        return abs(a.x-b.x) + abs(a.y-b.y)
    def euclidean_distance(self, a: Position, b: Position):
        return math.sqrt((a.x-b.x)**2+(a.y-b.y)**2)
    def search(self, grid: Grid, start: Position, goal: Position, heuristic_func='manhattan') -> SearchResult:
        start_time = time.time()
        nodes_expanded = 0
        if start == goal: return SearchResult([start], 0, 0, 0)
        heuristic = self.euclidean_distance if heuristic_func=='euclidean' else self.manhattan_distance
        queue = [(heuristic(start, goal), 0, start, [start])]
        visited = set()
        while queue:
            f, g, current, path = heapq.heappop(queue)
            if current in visited: continue
            visited.add(current); nodes_expanded += 1
            if current == goal:
                return SearchResult(path, g, nodes_expanded, time.time()-start_time)
            for neighbor in grid.get_neighbors(current):
                if neighbor not in visited:
                    cost = g + grid.get_terrain_cost(neighbor)
                    heapq.heappush(queue, (cost + heuristic(neighbor, goal), cost, neighbor, path + [neighbor]))
        return SearchResult([], float('inf'), nodes_expanded, time.time()-start_time)

####################
# Local Search     #
####################

class LocalSearchPlanner:
    def __init__(self, grid: Grid):
        self.grid = grid
    def evaluate_path_quality(self, path: List[Position]) -> float:
        if not path or len(path)<2: return float('inf')
        cost = 0
        for i in range(len(path)-1):
            if not self.grid.is_passable(path[i+1]): return float('inf')
            cost += self.grid.get_terrain_cost(path[i+1])
        return cost
    def generate_neighbor_paths(self, path: List[Position], start: Position, goal: Position) -> List[List[Position]]:
        if len(path)<3: return []
        neighbors = []
        for i in range(1, len(path)-1):
            for dx,dy in [(0,1),(0,-1),(1,0),(-1,0)]:
                npos = Position(path[i].x+dx, path[i].y+dy)
                if self.grid.is_valid(npos) and self.grid.is_passable(npos):
                    new_path = path.copy()
                    new_path[i] = npos
                    if self._is_path_connected(new_path):
                        neighbors.append(new_path)
        return neighbors[:10]
    def _is_path_connected(self, path):
        for i in range(len(path)-1):
            if abs(path[i].x-path[i+1].x)+abs(path[i].y-path[i+1].y) > 1:
                return False
        return True

class HillClimbingPlanner(LocalSearchPlanner):
    def replan(self, current_path, start, goal, max_iterations=30):
        start_time = time.time(); nodes_expanded=0
        if not current_path: return SearchResult([], float('inf'), 0, 0)
        solution = current_path.copy()
        quality = self.evaluate_path_quality(solution)
        for _ in range(max_iterations):
            neighbors = self.generate_neighbor_paths(solution, start, goal)
            nodes_expanded += len(neighbors)
            if not neighbors: break
            best = min(neighbors, key=lambda p: self.evaluate_path_quality(p), default=None)
            best_quality = self.evaluate_path_quality(best) if best else float('inf')
            if best and best_quality < quality:
                solution = best
                quality = best_quality
            else: break
        return SearchResult(solution, quality, nodes_expanded, time.time()-start_time)

class SimulatedAnnealingPlanner(LocalSearchPlanner):
    def replan(self, current_path, start, goal, initial_temperature=20.0, cooling_rate=0.85, max_iterations=50):
        start_time = time.time(); nodes_expanded=0
        if not current_path: return SearchResult([], float('inf'), 0, 0)
        current, current_q = current_path.copy(), self.evaluate_path_quality(current_path)
        best = list(current); best_q = current_q
        temp = initial_temperature
        for _ in range(max_iterations):
            neighbors = self.generate_neighbor_paths(current, start, goal)
            if not neighbors: break
            neighbor = random.choice(neighbors)
            nodes_expanded += 1
            nq = self.evaluate_path_quality(neighbor)
            if nq < current_q or random.random() < math.exp((current_q-nq)/temp):
                current, current_q = neighbor, nq
                if nq < best_q: best, best_q = list(neighbor), nq
            temp *= cooling_rate
            if temp<0.1: break
        return SearchResult(best, best_q, nodes_expanded, time.time()-start_time)

###################
# Dynamic Obstacles
###################

class DynamicObstacle:
    def __init__(self, position: Position, path: List[Position], speed: int = 1):
        self.path = path
        self.speed = speed
        self.initial_position = position
    def get_position_at_time(self, t: int) -> Position:
        if not self.path: return self.initial_position
        return self.path[(t*self.speed) % len(self.path)]

########################
# Agent Implementation #
########################

class AutonomousDeliveryAgent:
    def __init__(self, grid: Grid):
        self.grid = grid
        self.current_position = None
        self.goal_position = None
        self.current_path = []
        self.dynamic_obstacles = []
        self.time_step = 0
        self.bfs = BreadthFirstSearch()
        self.ucs = UniformCostSearch()
        self.astar = AStarSearch()
        self.hill = HillClimbingPlanner(grid)
        self.anneal = SimulatedAnnealingPlanner(grid)
    def add_dynamic_obstacle(self, obstacle: DynamicObstacle):
        self.dynamic_obstacles.append(obstacle)
    def update_dynamic_obstacles(self):
        for x in range(self.grid.width):
            for y in range(self.grid.height):
                if self.grid.cells[x][y].cell_type == CellType.DYNAMIC_OBSTACLE:
                    self.grid.cells[x][y].cell_type = CellType.FREE
        for obstacle in self.dynamic_obstacles:
            pos = obstacle.get_position_at_time(self.time_step)
            if self.grid.is_valid(pos):
                self.grid.set_cell_type(pos, CellType.DYNAMIC_OBSTACLE)
    def is_path_blocked(self, path: List[Position], horizon:int=10) -> bool:
        for i,pos in enumerate(path):
            at_time = self.time_step + i
            if at_time > self.time_step+horizon: break
            for ob in self.dynamic_obstacles:
                if ob.get_position_at_time(at_time) == pos:
                    return True
        return False
    def plan_path(self, algorithm='astar', heuristic='manhattan') -> SearchResult:
        if not self.current_position or not self.goal_position:
            return SearchResult()
        self.update_dynamic_obstacles()
        if algorithm == 'bfs':       return self.bfs.search(self.grid, self.current_position, self.goal_position)
        if algorithm == 'ucs':       return self.ucs.search(self.grid, self.current_position, self.goal_position)
        if algorithm == 'astar':     return self.astar.search(self.grid, self.current_position, self.goal_position, heuristic)
        raise ValueError("Unknown algorithm")
    def replan_path(self, method='hill_climbing') -> SearchResult:
        if method=='hill_climbing':
            return self.hill.replan(self.current_path,self.current_position,self.goal_position)
        if method=='simulated_annealing':
            return self.anneal.replan(self.current_path,self.current_position,self.goal_position)
        raise ValueError("Unknown replanning method")
    def execute_delivery(self, start: Position, goal: Position, algorithm: str = 'astar', max_steps=1000) -> Dict:
        self.current_position, self.goal_position, self.time_step = start, goal, 0
        self.grid.set_cell_type(start, CellType.START)
        self.grid.set_cell_type(goal, CellType.GOAL)
        log = {'algorithm': algorithm, 'start': (start.x,start.y), 'goal':(goal.x,goal.y),
               'path_found': False, 'total_cost':0, 'total_nodes_expanded':0, 'total_time':0,
               'replanning_events':[], 'final_path':[]}
        result = self.plan_path(algorithm)
        log['total_nodes_expanded'] += result.nodes_expanded
        log['total_time'] += result.time_taken

        if not result.found_solution:
            return log
        self.current_path = result.path
        step = 0

        while step < max_steps and self.current_position != self.goal_position:
            if self.is_path_blocked(self.current_path[step:]):
                re_result = self.replan_path('simulated_annealing')
                log['replanning_events'].append({
                    'time_step': self.time_step, 'trigger':'dynamic_obstacle_detected',
                    'new_path_cost': re_result.cost, 'nodes_expanded':re_result.nodes_expanded
                })
                log['total_nodes_expanded'] += re_result.nodes_expanded
                log['total_time'] += re_result.time_taken
                if re_result.found_solution:
                    self.current_path = re_result.path
                    step = 0
            if step < len(self.current_path)-1:
                nextpos = self.current_path[step+1]
                log['total_cost'] += self.grid.get_terrain_cost(nextpos)
                self.current_position = nextpos
                step += 1
            self.time_step += 1
            self.update_dynamic_obstacles()

        log['path_found'] = (self.current_position == self.goal_position)
        log['final_path'] = [(p.x, p.y) for p in self.current_path]
        return log

###################
# Map Generators
###################

class MapGenerator:
    @staticmethod
    def create_small_map():
        grid = Grid(10,10)
        obstacles = [(3,3),(3,4),(3,5),(6,6),(6,7),(7,6),(7,7)]
        for x,y in obstacles: grid.set_cell_type(Position(x,y),CellType.OBSTACLE)
        for x in range(2,5):
            for y in range(7,10): grid.set_terrain_cost(Position(x,y),3)
        return grid
    @staticmethod
    def create_medium_map():
        grid = Grid(20,20)
        for x in range(5,15):
            grid.set_cell_type(Position(x,5),CellType.OBSTACLE)
            grid.set_cell_type(Position(x,15),CellType.OBSTACLE)
        for y in range(5,16):
            grid.set_cell_type(Position(5,y),CellType.OBSTACLE)
            grid.set_cell_type(Position(15,y),CellType.OBSTACLE)
        for p in [Position(10,5),Position(5,10),Position(15,10)]:
            grid.set_cell_type(p,CellType.FREE)
        for x in range(0,5):
            for y in range(0,5): grid.set_terrain_cost(Position(x,y),2)
        return grid
    @staticmethod
    def create_large_map():
        grid = Grid(50,50)
        random.seed(42)
        for x in range(50):
            for y in range(50):
                if random.random()<0.2: grid.set_cell_type(Position(x,y),CellType.OBSTACLE)
                elif random.random()<0.3: grid.set_terrain_cost(Position(x,y),random.randint(2,5))
        grid.set_cell_type(Position(0,0),CellType.FREE)
        grid.set_cell_type(Position(49,49),CellType.FREE)
        grid.set_terrain_cost(Position(0,0),1)
        grid.set_terrain_cost(Position(49,49),1)
        return grid
    @staticmethod
    def create_dynamic_obstacle_map():
        grid = Grid(15,15)
        for x in range(5,10): grid.set_cell_type(Position(x,7),CellType.OBSTACLE)
        obstacles = [
            DynamicObstacle(Position(2,5),[Position(2,5),Position(3,5),Position(4,5),Position(3,5)],1),
            DynamicObstacle(Position(10,10),[Position(10,10),Position(11,10),Position(11,11),Position(10,11)],1)
        ]
        return grid, obstacles

class PerformanceEvaluator:
    def __init__(self): self.results=[]
    def evaluate_algorithm(self, agent, grid, start, goal, algo, num_runs=3):
        results = {'algorithm':algo,'runs':[], 'average_cost':0, 'average_nodes_expanded':0, 'average_time':0, 'success_rate':0}
        successful_runs=0
        for _ in range(num_runs):
            agent.current_position, agent.goal_position, agent.time_step = None, None, 0
            log = agent.execute_delivery(start, goal, algo)
            results['runs'].append(log)
            if log['path_found']:
                successful_runs += 1
                results['average_cost'] += log['total_cost']
                results['average_nodes_expanded'] += log['total_nodes_expanded']
                results['average_time'] += log['total_time']
        if successful_runs:
            results['average_cost']/=successful_runs
            results['average_nodes_expanded']/=successful_runs
            results['average_time']/=successful_runs
        results['success_rate'] = successful_runs/num_runs
        return results
    def compare_algorithms(self, grid, start, goal, dyn_obstacles=None):
        agent = AutonomousDeliveryAgent(grid)
        if dyn_obstacles:
            for ob in dyn_obstacles: agent.add_dynamic_obstacle(ob)
        algos = ['bfs','ucs','astar']
        return {algo:self.evaluate_algorithm(agent,grid,start,goal,algo) for algo in algos}
    def generate_test_report(self, results):
        lines = ["PATHFINDING ALGORITHM COMPARISON REPORT","="*50]
        for alg, data in results.items():
            lines.append(f"Algorithm: {alg.upper()}")
            lines.append(f"Success Rate: {data['success_rate']:.2%}")
            lines.append(f"Average Path Cost: {data['average_cost']:.2f}")
            lines.append(f"Average Nodes Expanded: {data['average_nodes_expanded']:.0f}")
            lines.append(f"Average Time: {data['average_time']:.4f} seconds")
            lines.append("-"*30)
        return "\n".join(lines)

#########################
## Command-line runner ##
#########################

class DeliveryAgentCLI:
    def __init__(self): self.parser = self.create_parser()
    def create_parser(self):
        parser = argparse.ArgumentParser(description="Autonomous Delivery Agent Pathfinding",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="EXAMPLES..."
        )
        parser.add_argument('--algorithm', '-a', choices=['bfs','ucs','astar'], default='astar')
        parser.add_argument('--heuristic', '-h', choices=['manhattan','euclidean'], default='manhattan')
        parser.add_argument('--map', '-m', choices=['small','medium','large','dynamic'])
        parser.add_argument('--map-file', '-f', type=str)
        parser.add_argument('--start', '-s', type=str, required=True)
        parser.add_argument('--goal', '-g', type=str, required=True)
        parser.add_argument('--compare-all', '-c', action='store_true')
        parser.add_argument('--test-dynamic', '-d', action='store_true')
        parser.add_argument('--runs', '-r', type=int, default=3)
        parser.add_argument('--output', '-o', type=str)
        parser.add_argument('--verbose', '-v', action='store_true')
        parser.add_argument('--display-grid', action='store_true')
        return parser
    def parse_position(self, pos_str: str):
        try: x,y=map(int,pos_str.strip().split(',')); return Position(x,y)
        except Exception: raise argparse.ArgumentTypeError("Invalid --start/--goal format: expected x,y")
    def load_map(self, args):
        if args.map:
            if args.map == 'small': return MapGenerator.create_small_map(), None
            if args.map == 'medium': return MapGenerator.create_medium_map(), None
            if args.map == 'large': return MapGenerator.create_large_map(), None
            if args.map == 'dynamic': return MapGenerator.create_dynamic_obstacle_map()
        if args.map_file:  # you can add JSON map loading here if needed.
            with open(args.map_file,'r') as f: data=json.load(f)
            grid = Grid(data['width'],data['height'])
            for cell in data['cells']:
                pos = Position(cell['x'],cell['y'])
                grid.set_cell_type(pos,CellType(cell['type']))
                grid.set_terrain_cost(pos,cell.get('terrain_cost',1))
            return grid, None
        raise ValueError("Specify --map or --map-file")
    def save_results(self, results, filename):
        with open(filename, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to {filename}")
    def run(self):
        args = self.parser.parse_args()
        start = self.parse_position(args.start)
        goal = self.parse_position(args.goal)
        grid, dynobs = self.load_map(args)
        if args.display_grid: grid.display()
        if args.compare_all:
            evaluator = PerformanceEvaluator()
            results = evaluator.compare_algorithms(grid, start, goal, dynobs)
            print(evaluator.generate_test_report(results))
            if args.output: self.save_results(results, args.output)
        elif args.test_dynamic:
            agent = AutonomousDeliveryAgent(grid)
            if dynobs: [agent.add_dynamic_obstacle(ob) for ob in dynobs]
            result = agent.execute_delivery(start, goal, args.algorithm)
            print("Dynamic replanning test results:")
            print(f"Success: {result['path_found']}\nTotal cost: {result['total_cost']}\nNodes expanded: {result['total_nodes_expanded']}\nReplanning events: {len(result['replanning_events'])}")
            if args.verbose and result['final_path']:
                path_str = ' -> '.join([f"({x},{y})" for x,y in result['final_path']])
                print(f"Path: {path_str}")
            if args.output: self.save_results(result, args.output)
        else:
            agent = AutonomousDeliveryAgent(grid)
            if dynobs: [agent.add_dynamic_obstacle(ob) for ob in dynobs]
            result = agent.execute_delivery(start, goal, args.algorithm)
            print(f"Algorithm: {args.algorithm.upper()}\nSuccess: {result['path_found']}\nPath cost: {result['total_cost']}\nNodes expanded: {result['total_nodes_expanded']}\nTime taken: {result['total_time']:.4f} seconds")
            if args.verbose and result['final_path']:
                path_str = ' -> '.join([f"({x},{y})" for x,y in result['final_path']])
                print(f"Path: {path_str}")
            if args.output: self.save_results(result, args.output)
        return 0

#################
# Main Entrypoint
#################

def run_demo():
    print("Autonomous Delivery Agent DEMO\n" + "-"*45)
    grid = MapGenerator.create_small_map()
    agent = AutonomousDeliveryAgent(grid)
    start = Position(0,0)
    goal = Position(9,9)
    print("Small Map (10x10) from (0,0)→(9,9)")
    for alg in ['bfs','ucs','astar']:
        result = agent.execute_delivery(start, goal, alg)
        print(f"{alg.upper():5} | Cost: {result['total_cost']:4.0f} | Nodes: {result['total_nodes_expanded']:4} | Time: {result['total_time']:.4f}s | Success: {'✓' if result['path_found'] else '✗'}")


if __name__ == '__main__':
    import sys
    if len(sys.argv)==1: run_demo()
    else:
        cli = DeliveryAgentCLI()
        exit(cli.run())
