# Autonomous Delivery Agent - CSA2001 AI/ML Project

**Course:** CSA2001 - Fundamentals of AI and ML  
**Project:** Autonomous Delivery Agent with Dynamic Pathfinding  
**Author:** [Your Name]  
**Date:** September 2025

## 🎯 Project Overview

This project implements an autonomous delivery agent that navigates a 2D grid city to deliver packages efficiently. The agent uses various pathfinding algorithms and can adapt to dynamic obstacles through intelligent replanning.

### Key Features
- **Environment Modeling**: Static obstacles, varying terrain costs, dynamic moving obstacles
- **Rational Agent**: Optimizes delivery efficiency under time and fuel constraints
- **Multiple Algorithms**: BFS, UCS, A*, Hill Climbing, Simulated Annealing
- **Dynamic Replanning**: Handles moving obstacles with local search strategies
- **Performance Evaluation**: Comprehensive testing and comparison framework

## 🚀 Quick Start

### Prerequisites
- Python 3.7 or higher
- No external dependencies (uses only Python standard library)

### Installation
```bash
git clone <your-repository-url>
cd autonomous-delivery-agent
```

### Basic Usage

#### Run Demo
```bash
python complete_delivery_agent.py
```

#### Single Algorithm Test
```bash
python complete_delivery_agent.py --algorithm astar --map small --start 0,0 --goal 9,9
```

#### Compare All Algorithms
```bash
python complete_delivery_agent.py --compare-all --map medium --start 0,0 --goal 19,19
```

#### Test Dynamic Replanning
```bash
python complete_delivery_agent.py --test-dynamic --map dynamic --start 0,0 --goal 14,14 --verbose
```

#### Custom Map from File
```bash
python complete_delivery_agent.py --algorithm astar --map-file maps/custom_map.json --start 1,1 --goal 8,8
```

## 📖 Command Line Options

| Option | Short | Description | Default |
|--------|-------|-------------|---------|
| `--algorithm` | `-a` | Algorithm to use (bfs, ucs, astar) | astar |
| `--heuristic` | `-h` | Heuristic for A* (manhattan, euclidean) | manhattan |
| `--map` | `-m` | Predefined map (small, medium, large, dynamic) | - |
| `--map-file` | `-f` | Custom map JSON file | - |
| `--start` | `-s` | Start position as x,y | Required |
| `--goal` | `-g` | Goal position as x,y | Required |
| `--compare-all` | `-c` | Compare all algorithms | False |
| `--test-dynamic` | `-d` | Test dynamic replanning | False |
| `--runs` | `-r` | Number of evaluation runs | 3 |
| `--output` | `-o` | Save results to JSON file | - |
| `--verbose` | `-v` | Enable verbose output | False |
| `--display-grid` | | Show grid layout | False |

## 🗺️ Map Types

### 1. Small Map (10×10)
- Basic obstacles and varied terrain
- Good for algorithm testing and debugging
- Fast execution for quick validation

### 2. Medium Map (20×20) 
- Maze-like structure with strategic gaps
- Moderate complexity for performance comparison
- Tests pathfinding efficiency

### 3. Large Map (50×50)
- Complex terrain with random obstacles
- Stress testing for algorithm scalability  
- Realistic performance evaluation

### 4. Dynamic Map (15×15)
- Moving obstacles with predictable patterns
- Tests dynamic replanning capabilities
- Demonstrates real-world adaptability

## 🧠 Algorithms Implemented

### Uninformed Search
- **BFS (Breadth-First Search)**: Guarantees shortest path in unweighted grids
- **UCS (Uniform Cost Search)**: Optimal for weighted terrain costs

### Informed Search  
- **A* Algorithm**: Uses admissible heuristics for optimal pathfinding
  - Manhattan distance (default) - admissible for 4-connected grids
  - Euclidean distance - provides tighter bounds

### Local Search (for Replanning)
- **Hill Climbing**: Fast greedy local optimization
- **Simulated Annealing**: Probabilistic search to escape local optima

## 📊 Performance Metrics

The system tracks and compares:
- **Path Cost**: Total movement cost considering terrain
- **Nodes Expanded**: Computational efficiency measure
- **Execution Time**: Algorithm speed comparison  
- **Success Rate**: Reliability across multiple runs
- **Replanning Events**: Dynamic adaptation frequency

## 📁 Project Structure

```
autonomous-delivery-agent/
├── complete_delivery_agent.py    # Main implementation
├── README.md                     # This documentation
├── requirements.txt              # Dependencies (none)
├── maps/                        # Sample map files
│   ├── small_map.json
│   ├── medium_map.json
│   ├── large_map.json
│   └── dynamic_map.json
├── tests/                       # Test scripts
│   ├── test_algorithms.py
│   └── test_maps.py
├── results/                     # Output directory
├── docs/                       # Additional documentation
│   └── algorithm_analysis.md
└── .gitignore
```

## 🧪 Testing

### Run All Tests
```bash
python tests/test_algorithms.py
python tests/test_maps.py
```

### Generate Experimental Data
```bash
# Small map comparison
python complete_delivery_agent.py --compare-all --map small --start 0,0 --goal 9,9 --output results/small_map_results.json

# Medium map comparison  
python complete_delivery_agent.py --compare-all --map medium --start 0,0 --goal 19,19 --output results/medium_map_results.json

# Large map performance
python complete_delivery_agent.py --compare-all --map large --start 0,0 --goal 49,49 --output results/large_map_results.json

# Dynamic replanning
python complete_delivery_agent.py --test-dynamic --map dynamic --start 0,0 --goal 14,14 --output results/dynamic_results.json --verbose
```

## 📈 Expected Results

### Algorithm Performance Comparison
- **A*** typically shows 40-60% fewer node expansions than BFS/UCS
- **Manhattan heuristic** proves admissible and efficient for 4-connected grids
- **Dynamic replanning** successfully handles moving obstacles
- **Simulated annealing** outperforms hill climbing in complex scenarios

### When Each Algorithm Excels
- **BFS**: Unweighted grids, guarantees minimum steps
- **UCS**: Weighted terrain, guarantees minimum cost  
- **A***: Best overall performance with admissible heuristics
- **Local Search**: Essential for real-time dynamic replanning

## 🔬 Academic Report Support

This implementation provides comprehensive data for academic analysis:

### Environment Model
- Grid-based representation with cell types and terrain costs
- Support for static and dynamic obstacles
- Configurable map generation with reproducible seeds

### Agent Design
- Rational decision-making with constraint optimization
- Multi-algorithm planning with performance tracking
- Dynamic replanning with local search strategies

### Experimental Framework
- Statistical evaluation over multiple runs
- Comparative analysis across algorithm families
- JSON export for detailed result analysis

## 🛠️ Customization

### Custom Maps
Create JSON map files with this format:
```json
{
  "width": 10,
  "height": 10,
  "cells": [
    {"x": 3, "y": 3, "type": 1, "terrain_cost": 1},
    {"x": 4, "y": 4, "type": 0, "terrain_cost": 2}
  ]
}
```

Cell types: `0=FREE, 1=OBSTACLE, 2=START, 3=GOAL, 4=DYNAMIC_OBSTACLE`

### Adding New Algorithms
1. Inherit from appropriate base class
2. Implement required search method  
3. Add to algorithm choices in CLI
4. Update comparison framework

## 📝 Academic Deliverables

### Source Code ✅
- Complete Python implementation with CLI
- Well-documented, modular design
- Git repository with commit history
- Reproducible results with fixed seeds

### Test Maps ✅  
- 4 required maps: small, medium, large, dynamic
- JSON format for easy modification
- Configurable terrain and obstacle patterns

### Performance Analysis ✅
- Automated comparison across all algorithms
- Statistical evaluation with multiple runs
- JSON export for report generation
- Comprehensive metrics tracking

### Documentation ✅
- Detailed README with usage examples
- Algorithm analysis and comparison
- Performance benchmarks and expectations
- Academic report data generation guide

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📜 License

This project is created for academic purposes as part of CSA2001 coursework.

## 🙏 Acknowledgments

- CSA2001 course materials and lectures
- Classic AI pathfinding algorithm references
- Python standard library for robust implementation

---

**For questions or issues, please refer to the course materials or contact the instructor.**
